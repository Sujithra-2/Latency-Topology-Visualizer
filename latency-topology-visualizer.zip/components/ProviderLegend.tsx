import React from 'react';
import { Provider } from '../lib/data';

const colors: Record<Provider, string> = { AWS: '#2563eb', GCP: '#06b6d4', Azure: '#7c3aed' };

export default function ProviderLegend() {
  return (
    <div className="legend">
      {Object.entries(colors).map(([p, c]) => (
        <div key={p} className="legendItem">
          <div className="marker" style={{ background: c }} />
          <div className="small">{p}</div>
        </div>
      ))}
    </div>
  );
}
