export function latencyColor(ms: number) {
  if (ms < 30) return '#22c55e'; // green
  if (ms < 100) return '#f59e0b'; // yellow
  return '#ef4444'; // red
}
