# Latency Topology Visualizer

This is a demo Next.js + TypeScript project that visualizes exchange server locations and synthetic latency data on a 3D globe. The demo is self-contained and uses an API route (/api/latency) to generate synthetic latency updates suitable for development and testing.

## Run locally

1. Install dependencies

```bash
npm install
```

2. Run dev server

```bash
npm run dev
# open http://localhost:3000
```

## What is implemented

- Interactive 3D globe using `react-globe.gl` (Three.js)
- Exchange server markers with provider colors
- Animated latency arcs between servers, color-coded by latency
- Synthetic real-time latency source (`/api/latency`) — polled every 7 seconds
- Historical in-memory latency history per pair and a simple line chart
- Controls for filtering by provider and selecting pairs
- Responsive basic layout and performance considerations

## How to replace synthetic data with a real API

- Identify a free latency API (or run your own ping workers) that returns latencies per pair.
- Update `pages/api/latency.ts` to proxy or fetch that data and normalize to the `{ pairs: [{from,to,latency}] }` structure.
- Optionally add server-side caching or edge functions for rate limiting.

## Assumptions

- For demo purposes we use synthetic latency so the project is free and reproducible.
- The historical chart is kept in-memory in the browser; for production you would persist to a time-series DB (InfluxDB, Prometheus, Timescale) or object store.

## Next steps / bonus features

- Add heatmap overlay, topology path simplification, dark/light theme toggle
- WebSocket or SSE for lower-latency updates
- Mobile touch-optimized control layout
- Export CSV/PNG reports
