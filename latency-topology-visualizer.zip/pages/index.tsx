import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import Controls from '../components/Controls';
import ProviderLegend from '../components/ProviderLegend';
import LatencyChart from '../components/LatencyChart';
import useSWR from 'swr';
import { EXCHANGES } from '../lib/data';

const GlobeMap = dynamic(() => import('../components/GlobeMap'), { ssr: false });

export default function Home() {
  const [provider, setProvider] = useState<string | null>(null);
  const [selectedPair, setSelectedPair] = useState<string | null>(null);
  const fetcher = (url: string) => fetch(url).then((r) => r.json());
  const { data } = useSWR('/api/latency', fetcher, { refreshInterval: 7000 });

  // simple in-memory history for the UI demo
  const [history, setHistory] = useState<Record<string, { ts: number; value: number }[]>>({});

  useEffect(() => {
    if (!data) return;
    const ts = data.ts;
    data.pairs.forEach((p: any) => {
      const key = `${p.from}__${p.to}`;
      setHistory((prev) => {
        const next = { ...prev };
        next[key] = (next[key] || []).concat({ ts, value: p.latency }).slice(-3600);
        return next;
      });
    });
  }, [data]);

  const currentPairs = data?.pairs || [];

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="header">Latency Topology Visualizer</div>
        <div className="small">Demo — synthetic latency data (local API)</div>
        <div style={{ marginTop: 12 }}>
          <Controls onFilterChange={(p) => setProvider(p)} provider={provider} />
        </div>

        <div style={{ marginTop: 12 }}>
          <ProviderLegend />
        </div>

        <div style={{ marginTop: 12 }}>
          <div className="header">Selected Pair</div>
          <div className="small">Pick a pair from the dropdown to view historical latency</div>
          <select style={{ width: '100%' }} onChange={(e) => setSelectedPair(e.target.value || null)}>
            <option value="">-- Select pair --</option>
            {currentPairs.map((p: any) => (
              <option key={`${p.from}__${p.to}`} value={`${p.from}__${p.to}`}>{p.from} → {p.to} — {p.latency}ms</option>
            ))}
          </select>
        </div>

        <div style={{ marginTop: 12 }}>
          <div className="header">Latency Chart</div>
          {selectedPair ? (
            <LatencyChart data={history[selectedPair] || []} />
          ) : (
            <div className="small">Select a pair to show historical latency (kept in-memory during session)</div>
          )}
        </div>

        <div className="footer">
          <div>Controls: filter providers, search, toggle layers (planned)</div>
          <div style={{ marginTop: 8 }}>Note: replace the `/api/latency` implementation with a real free latency API for production.</div>
        </div>
      </aside>

      <div className="canvasWrap">
        <GlobeMap providerFilter={provider} />
      </div>
    </div>
  );
}
