import type { NextApiRequest, NextApiResponse } from 'next';
import { EXCHANGES } from '../../lib/data';

// Simple in-memory historical store for demo (not persistent)
let HISTORY: Record<string, { ts: number; value: number }[]> = {};

function randLatency(base = 25) {
  // jittered latency between base and base*4
  const jitter = Math.random() * base * 3;
  return Math.round(base + jitter);
}

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  // generate pair latencies between every pair (directed) for demo
  const now = Date.now();
  const pairs: { from: string; to: string; latency: number }[] = [];

  for (let i = 0; i < EXCHANGES.length; i++) {
    for (let j = 0; j < EXCHANGES.length; j++) {
      if (i === j) continue;
      // base depends on geographic distance rough heuristic
      const base = 20 + Math.abs(EXCHANGES[i].lat - EXCHANGES[j].lat) * 1.5 + Math.abs(EXCHANGES[i].lng - EXCHANGES[j].lng) * 0.8;
      const l = randLatency(base);
      pairs.push({ from: EXCHANGES[i].id, to: EXCHANGES[j].id, latency: l });

      const key = `${EXCHANGES[i].id}__${EXCHANGES[j].id}`;
      HISTORY[key] = HISTORY[key] || [];
      HISTORY[key].push({ ts: now, value: l });
      // keep only 30 minutes of history in memory
      const cutoff = now - 1000 * 60 * 60 * 24; // 24 hours cap for demo
      HISTORY[key] = HISTORY[key].filter((d) => d.ts > cutoff);
    }
  }

  res.status(200).json({ ts: now, pairs });
}
