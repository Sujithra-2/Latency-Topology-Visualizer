export type Provider = 'AWS' | 'GCP' | 'Azure';

export interface ServerPoint {
  id: string;
  name: string;
  lat: number;
  lng: number;
  provider: Provider;
  regionCode?: string;
}

export const EXCHANGES: ServerPoint[] = [
  { id: 'binance_sg', name: 'Binance (SG)', lat: 1.3521, lng: 103.8198, provider: 'AWS', regionCode: 'ap-southeast-1' },
  { id: 'bybit_sg', name: 'Bybit (SG)', lat: 1.28, lng: 103.85, provider: 'GCP', regionCode: 'asia-southeast1' },
  { id: 'okx_nl', name: 'OKX (NL)', lat: 52.3702, lng: 4.8952, provider: 'Azure', regionCode: 'westeurope' },
  { id: 'deribit_nl', name: 'Deribit (NL)', lat: 52.3676, lng: 4.9041, provider: 'GCP', regionCode: 'europe-west4' },
  { id: 'binance_us', name: 'Binance (US)', lat: 37.7749, lng: -122.4194, provider: 'AWS', regionCode: 'us-west-1' }
];

export const CLOUD_REGIONS = [
  { provider: 'AWS', code: 'ap-southeast-1', lat: 1.2833, lng: 103.8333 },
  { provider: 'GCP', code: 'asia-southeast1', lat: 1.2833, lng: 103.8333 },
  { provider: 'Azure', code: 'westeurope', lat: 52.3667, lng: 4.9 },
  { provider: 'AWS', code: 'us-west-1', lat: 37.3382, lng: -121.8863 }
];
