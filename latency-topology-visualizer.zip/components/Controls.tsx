import React from 'react';
import { EXCHANGES } from '../lib/data';

interface Props {
  onFilterChange: (provider: string | null) => void;
  provider: string | null;
}

export default function Controls({ onFilterChange, provider }: Props) {
  return (
    <div className="controls">
      <div className="header">Filters</div>
      <div>
        <label className="small">Cloud Provider</label>
        <select value={provider ?? ''} onChange={(e) => onFilterChange(e.target.value || null)}>
          <option value="">All</option>
          <option value="AWS">AWS</option>
          <option value="GCP">GCP</option>
          <option value="Azure">Azure</option>
        </select>
      </div>

      <div style={{ marginTop: 12 }}>
        <label className="small">Search Exchange</label>
        <input placeholder="Search..." onChange={(e) => {/* optional hook */}} />
      </div>

      <div style={{ marginTop: 12 }}>
        <div className="small">Exchanges ({EXCHANGES.length})</div>
        <ul>
          {EXCHANGES.map((ex) => (
            <li key={ex.id} className="small">{ex.name} — {ex.provider}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
