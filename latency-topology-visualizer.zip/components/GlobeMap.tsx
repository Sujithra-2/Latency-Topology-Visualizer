import React, { useEffect, useRef, useState } from 'react';
import dynamic from 'next/dynamic';
import { EXCHANGES, ServerPoint } from '../lib/data';
import useSWR from 'swr';
import { latencyColor } from '../utils/color';

const Globe = dynamic(() => import('react-globe.gl').then((m) => (m as any).default), { ssr: false });

type Pair = { from: string; to: string; latency: number };

export default function GlobeMap({ providerFilter }: { providerFilter: string | null }) {
  const globeEl = useRef<any>(null);
  const [arcsData, setArcsData] = useState<any[]>([]);
  const [markers, setMarkers] = useState<ServerPoint[]>(EXCHANGES);

  const fetcher = (url: string) => fetch(url).then((r) => r.json());
  const { data } = useSWR('/api/latency', fetcher, { refreshInterval: 7000 });

  useEffect(() => {
    if (!data) return;
    const pairs: Pair[] = data.pairs;

    // map to arcs with color and altitude by latency
    const arcs = pairs.map((p) => {
      const from = EXCHANGES.find((e) => e.id === p.from)!;
      const to = EXCHANGES.find((e) => e.id === p.to)!;
      return {
        startLat: from.lat,
        startLng: from.lng,
        endLat: to.lat,
        endLng: to.lng,
        color: latencyColor(p.latency),
        latency: p.latency,
        stroke: Math.min(4, Math.max(1, p.latency / 50)),
        dashLength: 0.4
      };
    }).filter(Boolean);

    setArcsData(arcs);
  }, [data]);

  useEffect(() => {
    if (!globeEl.current) return;
    globeEl.current.pointOfView({ lat: 20, lng: 0, altitude: 2.5 }, 1000);
  }, []);

  const filteredMarkers = providerFilter ? EXCHANGES.filter((m) => m.provider === providerFilter) : EXCHANGES;

  return (
    <div style={{ width: '100%', height: '100vh' }}>
      <Globe 
        ref={globeEl}
        globeImageUrl="https://unpkg.com/three-globe/example/img/earth-night.jpg"
        backgroundImageUrl={null}
        arcsData={arcsData}
        arcColor={(d: any) => d.color}
        arcStroke={(d: any) => d.stroke}
        arcAltitude={(d: any) => Math.min(0.5, d.latency / 400)}
        arcsTransitionDuration={5000}
        pointsData={filteredMarkers}
        pointLat={(d: ServerPoint) => d.lat}
        pointLng={(d: ServerPoint) => d.lng}
        pointLabel={(d: ServerPoint) => `${d.name} — ${d.provider}`}
        pointRadius={0.6}
        pointAltitude={0.01}
        onPointClick={(pt: ServerPoint) => window.alert(`${pt.name}\nProvider: ${pt.provider}\nRegion:${pt.regionCode || '-'}`)}
      />
    </div>
  );
}
