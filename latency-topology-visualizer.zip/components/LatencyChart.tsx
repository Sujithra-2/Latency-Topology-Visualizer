import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface Point { ts: number; value: number }

export default function LatencyChart({ data }: { data: Point[] }) {
  const chartData = data.map((d) => ({ t: new Date(d.ts).toLocaleTimeString(), v: d.value })).slice(-60);
  return (
    <div style={{ height: 220 }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <XAxis dataKey="t" hide />
          <YAxis domain={[0, 'dataMax + 50']} />
          <Tooltip />
          <Line type="monotone" dataKey="v" stroke="#60a5fa" dot={false} strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
